package springnewproject.springin21minutes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springin21minutesApplicationTests {

	@Test
	void contextLoads() {
	}

}
