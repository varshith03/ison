package springnewproject.springin21minutes;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
@Repository
public class JdbResources {
	@Autowired
	private JdbcTemplate jdbctemp;
	private static final String InsertQ="insert into book(name) value('hello')";
	public void insert()
	{
		 jdbctemp.update(InsertQ);
	}

}
